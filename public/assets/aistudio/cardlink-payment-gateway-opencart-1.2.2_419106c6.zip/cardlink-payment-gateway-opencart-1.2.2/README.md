# Cardlink Checkout Payment Gateway

- Contributors: cardlink
- Tags: payments, payment-gateway
- Requires at least: 3.0.x.x
- Tested up to: 3.0.3.8
- Requires PHP: 7.x - 8.x
- License: GPLv2 or later
- License URI: http://www.gnu.org/licenses/gpl-2.0.html

## Changelog

- **1.2.2**
  - Order Status (Failed / Cancelled) admin field
  - Disable email notification on failed transaction
- **1.2.1**
  - Fix total amount.
- **1.2.0**
  - Added support for Cardlink's Background confirmation service.
  - Added support for XML API operations (Capture, Refund, Void, Status) within order page.
  - Plugin refactor: modernised, namespaced codebase with cleaner separation between gateway, admin, and checkout layers.
- **1.1.4**
  - Fix Order description. (If you already use IRIS with your own seller id, DO NOT install the new version!)
- **1.1.3**
  - Remove IRIS customer code field. (If you already use IRIS with your own seller id, DO NOT install the new version!)
  - Bug fix: success & return url
- **1.1.2**
  - IRIS for all acquirers
- **1.1.1**
  - Fix confirm and fail urls
- **1.1.0**
  - IRIS Support
- **1.0.5**
  - Fix Safari target
- **1.0.4**
  - Fix Shipping details
- **1.0.3**
  - Fix iframe style
- **1.0.2**
  - Add order status field
- **1.0.1**
  - Total installments number
- **1.0.0**
  - Initial release

## Description

Cardlink Payment Gateway allows you to accept payment through various schemes such as Visa, Mastercard, Maestro, American Express, Diners, Discover cards on your website, with or without variable installments.
This module aims to offer new payment solutions to Cardlink merchants for their Opencart 3.0.x online store without having web development knowledge. However, for the initial module installation some technical knowledge will be required.

Merchants with e-shops will be able to integrate the Cardlink Payment Gateway to their checkout page using the CSS layout that they want. Also, they can choose between redirect or IFRAME option for the payment environment. Once the payment is made, the customer is returned to the online store and the order is updated.
Once you have completed the requested tests and any changes to your website, you can activate your account and start accepting payments. 

## Features

1. A dropdown option for instance between Worldline, Nexi and Cardlink.
2. Option to enable test environment (sandbox). All transactions will be re-directed to the endpoint that represents the production environment by default. The endpoint will be different depending on which acquirer has been chosen from instance dropdown option.
3. Choose a custom title for payment method.
4. Ability to define the ranges of the total order amounts and the maximum number of installments for each range.
5. Option for pre-authorization or sale transactions.
6. Option to set different order statuses for transactions with a captured or authorized payment.
7. Option for a user tokenization service. The card token will be stored at the merchant’s e-shop database and will be used by customers to auto-complete future payments. 
8. In-store checkout option: the merchant can configure the payment process to take place inside a pop up with IFRAME to mask the redirection process from the customers. (The IRIS payments does not support the iframe feature).
9. A text field for providing the absolute or relative (to Cardlink Payment Gateway location on server) URL of custom CSS stylesheet, to apply custom CSS styles in the payment page.
10. Translation ready for Greek & English languages.
11.	IRIS payments. Upon installation, an extra payment is created. (The IRIS payments does not support the iframe feature).
12. Secondary actions now available using our CMS plugin (Capture of preauth, Refund, Void, Status Request).

## Installation

Firstly, find the plugins in the "INSTALL" folder. 
cardlink-payment-opencart.ocmod.zip

From your administration, go to ``Extensions > Installer`` and click on the ``Upload`` button.

![image001](https://developer.cardlink.gr/downloads/cardlink-payment-gateway-opencart-assets/image001.png)

Find it and select it through the popup file browser. Once the module’s ``ocmod.zip`` file has been uploaded and the module installed, you will see the below sucess message.
![image002](https://developer.cardlink.gr/downloads/cardlink-payment-gateway-opencart-assets/image002.png)

After the success uploading go to ``Extensions > Extensions`` and filter the extensions by ``Payment``.
Find the ``Cardlink`` extension and click on the green icon on the right with the plus icon. 

## Secondary Transactions

Secondary actions now available using our CMS plugin (Capture of preauth, Refund,
Void, Status Request).
From the plugin dashboard, you can enable the capability to complete secondary
transactions via XML API without leaving the plugin.
*A request to enable the XML channel for secondary transactions on Cardlink must be
submitted for your MID, and the plugin must be activated for it (Capture of preauth,
Refund, Void).
**Regarding preauthorization transactions, within the order, there is the option for
Partial or Full Capture of preauth (completing the pre-approved amount) directly from
the transactions page:



## Screenshots

1. The Cardlink Payment Gateway admin page used to configure the settings (``Extensions > Extensions > Payments > Cardlink > Edit``).
![image003](https://developer.cardlink.gr/downloads/cardlink-payment-gateway-opencart-assets/image003.png) 
1. The Cardlink Payment Gateway IRIS admin page used to configure the settings (``Extensions > Extensions > Payments > Cardlink Iris > Edit``).
![image005](https://developer.cardlink.gr/downloads/cardlink-payment-gateway-opencart-assets/image005.png) 
3. This is the front-end of Cardlink Payment Gateway plugin located in checkout page.
![image005](https://developer.cardlink.gr/downloads/cardlink-payment-gateway-opencart-assets/image004.png)

##  Support tickets

In case that you face any technical issue during the installation process, you can contact the Cardlink e-commerce team at ecommerce_support@cardlink.gr .